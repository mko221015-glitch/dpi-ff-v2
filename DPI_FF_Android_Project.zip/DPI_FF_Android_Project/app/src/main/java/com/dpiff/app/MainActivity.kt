package com.dpiff.app

import android.app.Activity
import android.os.Bundle
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(15, 15, 15)
    private val panel = Color.rgb(29, 29, 29)
    private val red = Color.rgb(255, 48, 48)
    private val white = Color.WHITE
    private val muted = Color.rgb(180, 180, 180)
    private lateinit var dpiInput: EditText
    private lateinit var currentText: TextView
    private lateinit var commandText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }
        scroll.addView(root)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "DPI FF"
            textSize = 32f
            setTextColor(red)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "CÔNG CỤ HỖ TRỢ KÉO TÂM"
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(22))
        }
        root.addView(subtitle, matchWrap())

        val current = card()
        currentText = TextView(this).apply {
            text = "DPI hiện tại: ${resources.displayMetrics.densityDpi}"
            textSize = 18f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        }
        current.addView(currentText)
        root.addView(current, matchWrap())

        val label = TextView(this).apply {
            text = "Nhập DPI muốn đặt"
            textSize = 15f
            setTextColor(white)
            setPadding(0, dp(20), 0, dp(8))
        }
        root.addView(label)

        dpiInput = EditText(this).apply {
            hint = "Ví dụ: 420"
            setHintTextColor(Color.GRAY)
            setTextColor(white)
            textSize = 20f
            inputType = 2
            setSingleLine(true)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(panel)
        }
        root.addView(dpiInput, matchWrap())

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val minus = actionButton("− 20") {
            val n = dpiInput.text.toString().toIntOrNull() ?: resources.displayMetrics.densityDpi
            dpiInput.setText((n - 20).coerceAtLeast(100).toString())
        }
        val plus = actionButton("+ 20") {
            val n = dpiInput.text.toString().toIntOrNull() ?: resources.displayMetrics.densityDpi
            dpiInput.setText((n + 20).coerceAtMost(1000).toString())
        }
        row.addView(minus, LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(6) })
        row.addView(plus, LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(6) })
        root.addView(row, matchWrap().apply { topMargin = dp(12) })

        root.addView(actionButton("TẠO LỆNH CHỈNH DPI", red) { makeSetCommand() },
            matchWrap().apply { topMargin = dp(14) })

        commandText = TextView(this).apply {
            text = "Lệnh ADB sẽ hiện ở đây."
            textSize = 13f
            setTextColor(muted)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(panel)
        }
        root.addView(commandText, matchWrap().apply { topMargin = dp(12) })

        root.addView(actionButton("SAO CHÉP LỆNH", panel) { copyCommand() },
            matchWrap().apply { topMargin = dp(8) })

        root.addView(actionButton("KHÔI PHỤC DPI MẶC ĐỊNH", panel) {
            commandText.text = "adb shell wm density reset"
            Toast.makeText(this, "Đã tạo lệnh khôi phục. Hãy chạy lệnh bằng ADB.", Toast.LENGTH_LONG).show()
        }, matchWrap().apply { topMargin = dp(10) })

        val note = TextView(this).apply {
            text = "\nLƯU Ý\nỨng dụng tạo lệnh ADB, không tự thay đổi DPI. Hãy chạy lệnh bằng ADB trên thiết bị đã kết nối. Ghi lại DPI ban đầu và chỉ thay đổi từng bước nhỏ. DPI không đảm bảo tăng headshot; nó chỉ thay đổi mật độ hiển thị."
            textSize = 12f
            setTextColor(muted)
            setPadding(dp(4), dp(12), dp(4), 0)
        }
        root.addView(note, matchWrap())
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        setBackgroundColor(panel)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun actionButton(label: String, color: Int = red, click: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 13f
            setTextColor(white)
            setBackgroundColor(color)
            isAllCaps = false
            setOnClickListener { click() }
        }
    }

    private fun makeSetCommand() {
        val value = dpiInput.text.toString().toIntOrNull()
        if (value == null || value !in 100..1000) {
            Toast.makeText(this, "Nhập DPI hợp lệ từ 100 đến 1000.", Toast.LENGTH_LONG).show()
            return
        }
        commandText.text = "adb shell wm density $value"
        Toast.makeText(this, "Đã tạo lệnh. Chưa áp dụng DPI.", Toast.LENGTH_LONG).show()
    }

    private fun copyCommand() {
        val command = commandText.text.toString()
        if (!command.startsWith("adb ")) {
            Toast.makeText(this, "Hãy tạo lệnh trước.", Toast.LENGTH_SHORT).show()
            return
        }
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("DPI FF ADB command", command))
        Toast.makeText(this, "Đã sao chép lệnh.", Toast.LENGTH_SHORT).show()
    }
}
