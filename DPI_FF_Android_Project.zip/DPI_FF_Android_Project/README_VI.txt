DPI FF - MÃ NGUỒN ANDROID

Tính năng:
- Hiển thị densityDpi mà ứng dụng đang đọc được.
- Nhập DPI và tạo lệnh ADB.
- Nút tăng/giảm 20.
- Sao chép lệnh đặt DPI.
- Tạo lệnh khôi phục DPI mặc định.

QUAN TRỌNG:
Ứng dụng này KHÔNG tự chạy lệnh ADB. Android không cho ứng dụng thông thường tự thay đổi mật độ hiển thị hệ thống nếu không có quyền đặc biệt. Bạn cần chạy lệnh được sao chép bằng ADB trên thiết bị đã kết nối.

Lệnh đặt:
adb shell wm density 420

Lệnh khôi phục:
adb shell wm density reset

Cách tạo APK:
1. Mở thư mục dự án bằng Android Studio.
2. Cài Android SDK Platform 35 và JDK 17 nếu được yêu cầu.
3. Chọn Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK debug thường nằm tại app/build/outputs/apk/debug/app-debug.apk.

Đây là mã nguồn dự án, chưa phải APK đã biên dịch và kiểm thử trên máy thật.

TÙY CHỌN BIÊN DỊCH APK TỰ ĐỘNG BẰNG GITHUB (không cần cài Android Studio):
1. Tạo tài khoản/đăng nhập GitHub và tạo repository mới.
2. Tải lên toàn bộ nội dung thư mục dự án này (bao gồm thư mục .github).
3. Mở tab Actions, chọn workflow "Build DPI FF APK", bấm Run workflow.
4. Khi chạy xong, mở lần chạy thành công và tải artifact "DPI-FF-debug-apk".
5. Giải nén artifact để lấy app-debug.apk.

Workflow trên chỉ biên dịch APK debug; chưa chứng minh app đã được kiểm thử trên mọi thiết bị.
